﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_Gustavo
{
    public partial class FrmQuestao02 : Form
    {
        public FrmQuestao02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int QntP = int.Parse(txtP.Text);
            int QntM = int.Parse(txtM.Text);
            int QntG = int.Parse(txtG.Text);
            float total;

            total = QntP * 12 + QntM * 14 + QntG * 22;




        }
    }
}

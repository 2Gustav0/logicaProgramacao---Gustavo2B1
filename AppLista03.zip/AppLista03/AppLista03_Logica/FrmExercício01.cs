﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class FrmExercício01 : Form
    {
        public FrmExercício01()
        {
            InitializeComponent();
        }
        private void btnSomar_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            MessageBox.Show("Soma = "+ (num1 + num3));
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            MessageBox.Show("Média = " + ((num1 + num2 + num3)/3));
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float porc1, porc2, porc3;

            porc1 = num1 / (num1 + num2 + num3) * 100;
            porc2 = num2 / (num1 + num2 + num3) * 100;
            porc3 = num3 / (num1 + num2 + num3) * 100;

            MessageBox.Show("Porcentagem de num1 = " + porc1);
            MessageBox.Show("Porcentagem de num2 = " + porc2);
            MessageBox.Show("Porcentagem de num3 = " + porc3);
        }
    }
}

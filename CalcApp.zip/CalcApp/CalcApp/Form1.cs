﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class FrmCalculadora : Form
    {
        public FrmCalculadora()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Você digitou um algarismo");
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 7");
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 8");
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 9");
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 4");
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 5");
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 6");
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 1");
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 2");
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 3");
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão 0");
        }

        private void btnDecimal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão de decimal");
        }

        private void btnAc_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você limpou um algarismo");
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão de multiplicação");
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão de porcentagem");
        }

        private void btnsubtrair_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão de subtração");
        }

        private void btndividir_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão de divisão");
        }

        private void btnsomar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão de somar");
        }

        private void btnIgual_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você clicou no botão de igual");
        }
    }
}

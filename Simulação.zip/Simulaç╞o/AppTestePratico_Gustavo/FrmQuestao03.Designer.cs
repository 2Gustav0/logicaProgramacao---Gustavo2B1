﻿namespace AppTestePratico_Gustavo
{
    partial class FrmQuestao03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblProduto1 = new System.Windows.Forms.Label();
            this.lblProduto2 = new System.Windows.Forms.Label();
            this.lblProduto3 = new System.Windows.Forms.Label();
            this.lblPreco1 = new System.Windows.Forms.Label();
            this.lblPreco2 = new System.Windows.Forms.Label();
            this.lblPreco3 = new System.Windows.Forms.Label();
            this.txtProd1 = new System.Windows.Forms.TextBox();
            this.txtProd2 = new System.Windows.Forms.TextBox();
            this.txtProd3 = new System.Windows.Forms.TextBox();
            this.txtPreco1 = new System.Windows.Forms.TextBox();
            this.txtPreco2 = new System.Windows.Forms.TextBox();
            this.txtPreco3 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblParcela1 = new System.Windows.Forms.Label();
            this.lblParcela2 = new System.Windows.Forms.Label();
            this.lblParcela3 = new System.Windows.Forms.Label();
            this.lblParcela4 = new System.Windows.Forms.Label();
            this.lblParcela5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblResult1 = new System.Windows.Forms.Label();
            this.lblResult2 = new System.Windows.Forms.Label();
            this.lblResult3 = new System.Windows.Forms.Label();
            this.lblResult4 = new System.Windows.Forms.Label();
            this.lblResult5 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(226, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "Loja de Games";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.Controls.Add(this.label1);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 100);
            this.panel1.TabIndex = 1;
            // 
            // lblProduto1
            // 
            this.lblProduto1.AutoSize = true;
            this.lblProduto1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduto1.Location = new System.Drawing.Point(20, 22);
            this.lblProduto1.Name = "lblProduto1";
            this.lblProduto1.Size = new System.Drawing.Size(123, 29);
            this.lblProduto1.TabIndex = 2;
            this.lblProduto1.Text = "Produto 1:";
            // 
            // lblProduto2
            // 
            this.lblProduto2.AutoSize = true;
            this.lblProduto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduto2.Location = new System.Drawing.Point(18, 124);
            this.lblProduto2.Name = "lblProduto2";
            this.lblProduto2.Size = new System.Drawing.Size(123, 29);
            this.lblProduto2.TabIndex = 3;
            this.lblProduto2.Text = "Produto 2:";
            // 
            // lblProduto3
            // 
            this.lblProduto3.AutoSize = true;
            this.lblProduto3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduto3.Location = new System.Drawing.Point(20, 230);
            this.lblProduto3.Name = "lblProduto3";
            this.lblProduto3.Size = new System.Drawing.Size(123, 29);
            this.lblProduto3.TabIndex = 4;
            this.lblProduto3.Text = "Produto 3:";
            // 
            // lblPreco1
            // 
            this.lblPreco1.AutoSize = true;
            this.lblPreco1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco1.Location = new System.Drawing.Point(285, 22);
            this.lblPreco1.Name = "lblPreco1";
            this.lblPreco1.Size = new System.Drawing.Size(102, 29);
            this.lblPreco1.TabIndex = 6;
            this.lblPreco1.Text = "Preço 1:";
            // 
            // lblPreco2
            // 
            this.lblPreco2.AutoSize = true;
            this.lblPreco2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco2.Location = new System.Drawing.Point(285, 124);
            this.lblPreco2.Name = "lblPreco2";
            this.lblPreco2.Size = new System.Drawing.Size(102, 29);
            this.lblPreco2.TabIndex = 7;
            this.lblPreco2.Text = "Preço 2:";
            // 
            // lblPreco3
            // 
            this.lblPreco3.AutoSize = true;
            this.lblPreco3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco3.Location = new System.Drawing.Point(285, 230);
            this.lblPreco3.Name = "lblPreco3";
            this.lblPreco3.Size = new System.Drawing.Size(102, 29);
            this.lblPreco3.TabIndex = 8;
            this.lblPreco3.Text = "Preço 3:";
            // 
            // txtProd1
            // 
            this.txtProd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProd1.Location = new System.Drawing.Point(23, 54);
            this.txtProd1.Name = "txtProd1";
            this.txtProd1.Size = new System.Drawing.Size(161, 35);
            this.txtProd1.TabIndex = 9;
            // 
            // txtProd2
            // 
            this.txtProd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProd2.Location = new System.Drawing.Point(25, 156);
            this.txtProd2.Name = "txtProd2";
            this.txtProd2.Size = new System.Drawing.Size(161, 35);
            this.txtProd2.TabIndex = 10;
            // 
            // txtProd3
            // 
            this.txtProd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProd3.Location = new System.Drawing.Point(25, 262);
            this.txtProd3.Name = "txtProd3";
            this.txtProd3.Size = new System.Drawing.Size(161, 35);
            this.txtProd3.TabIndex = 11;
            // 
            // txtPreco1
            // 
            this.txtPreco1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPreco1.Location = new System.Drawing.Point(290, 54);
            this.txtPreco1.Name = "txtPreco1";
            this.txtPreco1.Size = new System.Drawing.Size(161, 35);
            this.txtPreco1.TabIndex = 12;
            // 
            // txtPreco2
            // 
            this.txtPreco2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPreco2.Location = new System.Drawing.Point(290, 156);
            this.txtPreco2.Name = "txtPreco2";
            this.txtPreco2.Size = new System.Drawing.Size(161, 35);
            this.txtPreco2.TabIndex = 13;
            // 
            // txtPreco3
            // 
            this.txtPreco3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPreco3.Location = new System.Drawing.Point(290, 262);
            this.txtPreco3.Name = "txtPreco3";
            this.txtPreco3.Size = new System.Drawing.Size(161, 35);
            this.txtPreco3.TabIndex = 14;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkCyan;
            this.panel2.Controls.Add(this.lblProduto1);
            this.panel2.Controls.Add(this.txtPreco3);
            this.panel2.Controls.Add(this.lblProduto2);
            this.panel2.Controls.Add(this.txtPreco2);
            this.panel2.Controls.Add(this.lblProduto3);
            this.panel2.Controls.Add(this.txtPreco1);
            this.panel2.Controls.Add(this.lblPreco1);
            this.panel2.Controls.Add(this.txtProd3);
            this.panel2.Controls.Add(this.lblPreco2);
            this.panel2.Controls.Add(this.txtProd2);
            this.panel2.Controls.Add(this.lblPreco3);
            this.panel2.Controls.Add(this.txtProd1);
            this.panel2.Location = new System.Drawing.Point(12, 108);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(497, 306);
            this.panel2.TabIndex = 15;
            // 
            // lblParcela1
            // 
            this.lblParcela1.AutoSize = true;
            this.lblParcela1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela1.Location = new System.Drawing.Point(15, 22);
            this.lblParcela1.Name = "lblParcela1";
            this.lblParcela1.Size = new System.Drawing.Size(196, 31);
            this.lblParcela1.TabIndex = 16;
            this.lblParcela1.Text = "01 Parcela de -";
            // 
            // lblParcela2
            // 
            this.lblParcela2.AutoSize = true;
            this.lblParcela2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela2.Location = new System.Drawing.Point(15, 78);
            this.lblParcela2.Name = "lblParcela2";
            this.lblParcela2.Size = new System.Drawing.Size(196, 31);
            this.lblParcela2.TabIndex = 17;
            this.lblParcela2.Text = "02 Parcela de -";
            // 
            // lblParcela3
            // 
            this.lblParcela3.AutoSize = true;
            this.lblParcela3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela3.Location = new System.Drawing.Point(15, 136);
            this.lblParcela3.Name = "lblParcela3";
            this.lblParcela3.Size = new System.Drawing.Size(196, 31);
            this.lblParcela3.TabIndex = 18;
            this.lblParcela3.Text = "03 Parcela de -";
            // 
            // lblParcela4
            // 
            this.lblParcela4.AutoSize = true;
            this.lblParcela4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela4.Location = new System.Drawing.Point(15, 195);
            this.lblParcela4.Name = "lblParcela4";
            this.lblParcela4.Size = new System.Drawing.Size(196, 31);
            this.lblParcela4.TabIndex = 19;
            this.lblParcela4.Text = "04 Parcela de -";
            // 
            // lblParcela5
            // 
            this.lblParcela5.AutoSize = true;
            this.lblParcela5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela5.Location = new System.Drawing.Point(15, 253);
            this.lblParcela5.Name = "lblParcela5";
            this.lblParcela5.Size = new System.Drawing.Size(196, 31);
            this.lblParcela5.TabIndex = 20;
            this.lblParcela5.Text = "05 Parcela de -";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.panel3.Controls.Add(this.lblResult5);
            this.panel3.Controls.Add(this.lblResult4);
            this.panel3.Controls.Add(this.lblResult3);
            this.panel3.Controls.Add(this.lblResult2);
            this.panel3.Controls.Add(this.lblResult1);
            this.panel3.Controls.Add(this.lblParcela5);
            this.panel3.Controls.Add(this.lblParcela1);
            this.panel3.Controls.Add(this.lblParcela4);
            this.panel3.Controls.Add(this.lblParcela2);
            this.panel3.Controls.Add(this.lblParcela3);
            this.panel3.Location = new System.Drawing.Point(507, 108);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(281, 306);
            this.panel3.TabIndex = 21;
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnCalcular.Location = new System.Drawing.Point(12, 411);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(776, 36);
            this.btnCalcular.TabIndex = 22;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblResult1
            // 
            this.lblResult1.AutoSize = true;
            this.lblResult1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult1.Location = new System.Drawing.Point(208, 29);
            this.lblResult1.Name = "lblResult1";
            this.lblResult1.Size = new System.Drawing.Size(0, 24);
            this.lblResult1.TabIndex = 21;
            // 
            // lblResult2
            // 
            this.lblResult2.AutoSize = true;
            this.lblResult2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult2.Location = new System.Drawing.Point(208, 85);
            this.lblResult2.Name = "lblResult2";
            this.lblResult2.Size = new System.Drawing.Size(0, 24);
            this.lblResult2.TabIndex = 22;
            // 
            // lblResult3
            // 
            this.lblResult3.AutoSize = true;
            this.lblResult3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult3.Location = new System.Drawing.Point(208, 143);
            this.lblResult3.Name = "lblResult3";
            this.lblResult3.Size = new System.Drawing.Size(0, 24);
            this.lblResult3.TabIndex = 23;
            // 
            // lblResult4
            // 
            this.lblResult4.AutoSize = true;
            this.lblResult4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult4.Location = new System.Drawing.Point(208, 202);
            this.lblResult4.Name = "lblResult4";
            this.lblResult4.Size = new System.Drawing.Size(0, 24);
            this.lblResult4.TabIndex = 24;
            // 
            // lblResult5
            // 
            this.lblResult5.AutoSize = true;
            this.lblResult5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult5.Location = new System.Drawing.Point(208, 260);
            this.lblResult5.Name = "lblResult5";
            this.lblResult5.Size = new System.Drawing.Size(0, 24);
            this.lblResult5.TabIndex = 25;
            // 
            // FrmQuestao03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "FrmQuestao03";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblProduto1;
        private System.Windows.Forms.Label lblProduto2;
        private System.Windows.Forms.Label lblProduto3;
        private System.Windows.Forms.Label lblPreco1;
        private System.Windows.Forms.Label lblPreco2;
        private System.Windows.Forms.Label lblPreco3;
        private System.Windows.Forms.TextBox txtProd1;
        private System.Windows.Forms.TextBox txtProd2;
        private System.Windows.Forms.TextBox txtProd3;
        private System.Windows.Forms.TextBox txtPreco1;
        private System.Windows.Forms.TextBox txtPreco2;
        private System.Windows.Forms.TextBox txtPreco3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblParcela1;
        private System.Windows.Forms.Label lblParcela2;
        private System.Windows.Forms.Label lblParcela3;
        private System.Windows.Forms.Label lblParcela4;
        private System.Windows.Forms.Label lblParcela5;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblResult5;
        private System.Windows.Forms.Label lblResult4;
        private System.Windows.Forms.Label lblResult3;
        private System.Windows.Forms.Label lblResult2;
        private System.Windows.Forms.Label lblResult1;
    }
}
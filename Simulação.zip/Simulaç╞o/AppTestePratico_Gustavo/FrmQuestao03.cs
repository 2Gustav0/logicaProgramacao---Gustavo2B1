﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_Gustavo
{
    public partial class FrmQuestao03 : Form
    {
        public FrmQuestao03()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            float preco1 = float.Parse(txtPreco1.Text);
            float preco2 = float.Parse(txtPreco2.Text);
            float preco3 = float.Parse(txtPreco3.Text);
            float valorCompra;

            valorCompra = preco1 + preco2 + preco3;

            lblResult1.Text = (valorCompra / 1).ToString("C");
            lblResult2.Text = (valorCompra / 2).ToString("C");
            lblResult3.Text = (valorCompra / 3).ToString("C");
            lblResult4.Text = (valorCompra / 4).ToString("C");
            lblResult5.Text = (valorCompra / 5).ToString("C");


        }
    }
}

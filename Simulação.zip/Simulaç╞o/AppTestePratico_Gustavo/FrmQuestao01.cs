﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_Gustavo
{
    public partial class FrmQuestao1 : Form
    {
        public FrmQuestao1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int QntPaes = int.Parse(txtQntPaes.Text);
            int QntBroas = int.Parse(txtQntBroas.Text);
            float total;

            total = QntBroas * 1.50f + QntPaes * 0.12f;

            lblResultado.Text = "R$" + total;
        }

        private void FrmTeste_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void pnlQuestao1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

﻿namespace AppTestePratico_Gustavo
{
    partial class FrmQuestao1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao1));
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtQntPaes = new System.Windows.Forms.TextBox();
            this.txtQntBroas = new System.Windows.Forms.TextBox();
            this.lblQuantPaes = new System.Windows.Forms.Label();
            this.lblQuantBroas = new System.Windows.Forms.Label();
            this.pnlQuestao1 = new System.Windows.Forms.Panel();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblValor = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.blQuestão1 = new System.Windows.Forms.Label();
            this.pnlQuestao1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(8, 199);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(95, 58);
            this.btnCalcular.TabIndex = 0;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtQntPaes
            // 
            this.txtQntPaes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQntPaes.Location = new System.Drawing.Point(8, 53);
            this.txtQntPaes.Name = "txtQntPaes";
            this.txtQntPaes.Size = new System.Drawing.Size(228, 31);
            this.txtQntPaes.TabIndex = 1;
            // 
            // txtQntBroas
            // 
            this.txtQntBroas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQntBroas.Location = new System.Drawing.Point(8, 136);
            this.txtQntBroas.Name = "txtQntBroas";
            this.txtQntBroas.Size = new System.Drawing.Size(228, 31);
            this.txtQntBroas.TabIndex = 2;
            // 
            // lblQuantPaes
            // 
            this.lblQuantPaes.AutoSize = true;
            this.lblQuantPaes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantPaes.Location = new System.Drawing.Point(3, 21);
            this.lblQuantPaes.Name = "lblQuantPaes";
            this.lblQuantPaes.Size = new System.Drawing.Size(233, 25);
            this.lblQuantPaes.TabIndex = 3;
            this.lblQuantPaes.Text = "Quantidade de Pães:";
            // 
            // lblQuantBroas
            // 
            this.lblQuantBroas.AutoSize = true;
            this.lblQuantBroas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantBroas.Location = new System.Drawing.Point(3, 108);
            this.lblQuantBroas.Name = "lblQuantBroas";
            this.lblQuantBroas.Size = new System.Drawing.Size(241, 25);
            this.lblQuantBroas.TabIndex = 4;
            this.lblQuantBroas.Text = "Quantidade de Broas:";
            // 
            // pnlQuestao1
            // 
            this.pnlQuestao1.Controls.Add(this.lblResultado);
            this.pnlQuestao1.Controls.Add(this.lblValor);
            this.pnlQuestao1.Controls.Add(this.txtQntPaes);
            this.pnlQuestao1.Controls.Add(this.btnCalcular);
            this.pnlQuestao1.Controls.Add(this.lblQuantBroas);
            this.pnlQuestao1.Controls.Add(this.txtQntBroas);
            this.pnlQuestao1.Controls.Add(this.lblQuantPaes);
            this.pnlQuestao1.Location = new System.Drawing.Point(-1, 168);
            this.pnlQuestao1.Name = "pnlQuestao1";
            this.pnlQuestao1.Size = new System.Drawing.Size(797, 281);
            this.pnlQuestao1.TabIndex = 5;
            this.pnlQuestao1.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlQuestao1_Paint);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(109, 223);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(45, 25);
            this.lblResultado.TabIndex = 6;
            this.lblResultado.Text = "R$ ";
            // 
            // lblValor
            // 
            this.lblValor.AutoSize = true;
            this.lblValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValor.Location = new System.Drawing.Point(109, 199);
            this.lblValor.Name = "lblValor";
            this.lblValor.Size = new System.Drawing.Size(141, 24);
            this.lblValor.TabIndex = 5;
            this.lblValor.Text = "Valor a pagar:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Tomato;
            this.panel2.Controls.Add(this.blQuestão1);
            this.panel2.Location = new System.Drawing.Point(-1, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(794, 169);
            this.panel2.TabIndex = 6;
            // 
            // blQuestão1
            // 
            this.blQuestão1.AutoSize = true;
            this.blQuestão1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blQuestão1.Location = new System.Drawing.Point(10, 65);
            this.blQuestão1.Name = "blQuestão1";
            this.blQuestão1.Size = new System.Drawing.Size(255, 55);
            this.blQuestão1.TabIndex = 0;
            this.blQuestão1.Text = "Questão 1";
            // 
            // FrmQuestao1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnlQuestao1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuestao1";
            this.Text = "Form1";
            this.pnlQuestao1.ResumeLayout(false);
            this.pnlQuestao1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtQntPaes;
        private System.Windows.Forms.TextBox txtQntBroas;
        private System.Windows.Forms.Label lblQuantPaes;
        private System.Windows.Forms.Label lblQuantBroas;
        private System.Windows.Forms.Panel pnlQuestao1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label blQuestão1;
        private System.Windows.Forms.Label lblValor;
        private System.Windows.Forms.Label lblResultado;
    }
}

